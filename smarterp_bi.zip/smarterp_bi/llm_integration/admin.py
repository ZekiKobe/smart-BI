from django.contrib import admin
from .models import LLMProvider

admin.site.register(LLMProvider)
