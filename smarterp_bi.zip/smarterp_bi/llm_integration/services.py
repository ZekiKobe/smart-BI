# llm_integration/services.py
import httpx
from django.conf import settings
from .models import LLMProvider
import json
from django.db import connection
import re
from .models import LLMProvider, QueryHistory

class LLMService:
    def __init__(self, provider_name="gemini"):
        self.provider_name = provider_name
        self.provider = None
        self.client = httpx.AsyncClient(timeout=60.0)

    async def _load_provider(self):
        if not self.provider:
            try:
                self.provider = await LLMProvider.objects.aget(name=self.provider_name)
            except LLMProvider.DoesNotExist:
                raise ValueError(f"LLMProvider matching query does not exist: {self.provider_name}")

    async def generate_sql(self, prompt, schema_context):
        await self._load_provider()
        system_prompt = f"""You are an expert SQL analyst. Given the following database schema, write a SQL query to answer the user's prompt.
Database Schema:
{schema_context}

User Prompt: {prompt}

Rules:
- Only output the SQL query.
- Do not add any explanation or markdown formatting.
- The query should be compatible with PostgreSQL.
- Do not use table aliases unless it's necessary for self-joins.
"""
        # Google Gemini expects a different payload and endpoint
        if self.provider.name.lower() == "gemini":
            endpoint = f"{self.provider.base_url}:generateContent?key={self.provider.api_key}"
            payload = {
                "contents": [
                    {"parts": [
                        {"text": f"You are a SQL expert. Convert this natural language query to PostgreSQL SQL. Database schema: {schema_context} Query: {prompt} Return ONLY the SQL query, no explanations."}
                    ]}
                ]
            }
            headers = {
                "Content-Type": "application/json"
            }
        elif self.provider.name.lower() == "deepseek":
            # DeepSeek uses OpenAI-compatible API format
            endpoint = self.provider.base_url
            payload = {
                "model": "deepseek-coder",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a SQL expert. Convert natural language queries to PostgreSQL SQL. Return ONLY the SQL query, no explanations."
                    },
                    {
                        "role": "user",
                        "content": f"Database schema: {schema_context}\nQuery: {prompt}"
                    }
                ],
                "temperature": 0.3,
                "max_tokens": 1000
            }
            headers = {
                "Authorization": f"Bearer {self.provider.api_key}",
                "Content-Type": "application/json"
            }
        else:
            endpoint = f"{self.provider.base_url}/generate"
            payload = {
                "prompt": f"""
                You are a SQL expert. Convert this natural language query to PostgreSQL SQL.\nDatabase schema: {schema_context}\nQuery: {prompt}\nReturn ONLY the SQL query, no explanations.
                """,
                "temperature": 0.3,
                "max_tokens": 1000
            }
            headers = {
                "Authorization": f"Bearer {self.provider.api_key}",
                "Content-Type": "application/json"
            }

        response = await self.client.post(
            endpoint,
            headers=headers,
            json=payload
        )

        response.raise_for_status()
        # Parse response based on provider
        if self.provider.name.lower() == "gemini":
            return response.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        elif self.provider.name.lower() == "deepseek":
            return response.json()["choices"][0]["message"]["content"].strip()
        else:
            return response.json().get("text", "").strip()
    
    async def generate_dashboard_spec(self, prompt, schema_context):
        await self._load_provider()
        # Prompt the LLM to return a list of chart specs (type, title, SQL, metrics, groupby, all_columns)
        llm_prompt = (
            f"You are a BI assistant. Given the following user request:\n"
            f"\"{prompt}\"\n"
            f"and this database schema:\n{schema_context}\n"
            "Break the request into individual charts. For each chart, return:\n"
            "- type (one of: bar, line, pie, table)\n"
            "- title\n"
            "- sql (PostgreSQL dialect)\n"
            "- metrics (for bar/line/pie, e.g., ['sum__amount_total'])\n"
            "- groupby (for bar/line/pie, e.g., ['region'])\n"
            "- all_columns (for table, e.g., ['product_id', 'revenue'])\n"
            "IMPORTANT: Do not use Common Table Expressions (CTEs) or the WITH clause. Use subqueries if necessary.\n"
            "Return the result as a JSON array, e.g.:\n"
            "[{\"type\": \"bar\", \"title\": \"Total Sales by Region\", \"sql\": \"...\", \"metrics\": [\"sum__amount_total\"], \"groupby\": [\"region\"]}, ...]\n"
            "Do not include explanations, just the JSON."
        )
        endpoint = f"{self.provider.base_url}:generateContent?key={self.provider.api_key}"
        payload = {
            "contents": [{"parts": [{"text": llm_prompt}]}]
        }
        headers = {"Content-Type": "application/json"}
        response = await self.client.post(endpoint, headers=headers, json=payload)
        response.raise_for_status()
        import json
        text = response.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        # Remove code block markers if present
        if text.startswith("```json"):
            text = text.replace("```json", "").replace("```", "").strip()
        chart_specs = json.loads(text)
        print(f"[DEBUG] LLM chart specs: {chart_specs}")
        return chart_specs
    
    async def explain_data(self, data, question):
        # TODO: Replace this mock with actual LLM call
        # For now, return a sample explanation and insights
        return {
            "answer": "Sales dropped last quarter due to a decrease in demand in the North region.",
            "insights": [
                "North region sales decreased by 20% compared to previous quarter.",
                "Top 3 products saw a decline in sales volume.",
                "Overall revenue was impacted by seasonal trends."
            ]
        }

    @classmethod
    async def create(cls, provider_name=None):
        if provider_name:
            # Case-insensitive lookup
            provider = await LLMProvider.objects.filter(name__iexact=provider_name).afirst()
            if not provider:
                raise ValueError(f"LLMProvider matching query does not exist: {provider_name}")
        else:
            provider = await LLMProvider.objects.filter(is_active=True).afirst()
        if not provider:
            raise ValueError("No active LLMProvider found. Please configure at least one provider in the admin panel.")
        return cls(provider)

def get_schema_context():
    """
    Dynamically fetches the real schema from the connected PostgreSQL database.
    Returns a string describing all tables and their columns for the LLM.
    """
    print("[DEBUG] Starting get_schema_context")
    schema = {}
    with connection.cursor() as cursor:
        # Get all table names in the public schema
        print("[DEBUG] Fetching tables from public schema")
        cursor.execute("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
        """)
        tables = [row[0] for row in cursor.fetchall()]
        print(f"[DEBUG] Found tables: {tables}")
        
        for table in tables:
            print(f"[DEBUG] Fetching columns for table: {table}")
            cursor.execute(f"""
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_name = %s AND table_schema = 'public';
            """, [table])
            columns = cursor.fetchall()
            print(f"[DEBUG] Found columns: {columns}")
            schema[table] = {col: dtype for col, dtype in columns}
            
    # Format as a JSON string for the LLM
    schema_for_llm = {"tables": schema}
    print(f"[DEBUG] Final schema: {json.dumps(schema_for_llm, indent=2)}")
    return json.dumps(schema_for_llm, indent=2)

def generate_dynamic_schema(connection):
    # This function is no longer used but kept for reference
    """Generate schema by introspecting the database"""
    schema = {"tables": {}, "relationships": []}
    with connection.cursor() as cursor:
        # Get tables
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
        """)
        tables = [row[0] for row in cursor.fetchall()]
        
        for table in tables:
            # Get columns
            cursor.execute(f"""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = '{table}'
            """)
            schema["tables"][table] = {
                "columns": {row[0]: row[1] for row in cursor.fetchall()},
                "description": f"Table containing {table} data"
            }
            
            # Get foreign keys (relationships)
            cursor.execute(f"""
                SELECT
                    kcu.column_name,
                    ccu.table_name AS foreign_table,
                    ccu.column_name AS foreign_column
                FROM information_schema.table_constraints AS tc
                JOIN information_schema.key_column_usage AS kcu
                    ON tc.constraint_name = kcu.constraint_name
                JOIN information_schema.constraint_column_usage AS ccu
                    ON ccu.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name = '{table}'
            """)
            for row in cursor.fetchall():
                schema["relationships"].append(
                    f"{table}.{row[0]} references {row[1]}.{row[2]}"
                )
    
    return schema

def qualify_table_names(sql, schema="public"):
    # The regex matches table names with letters, numbers, and underscores
    pattern = re.compile(r'FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)', re.IGNORECASE)
    return pattern.sub(rf'FROM {schema}.\1', sql)