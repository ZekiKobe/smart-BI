# superset_integration/services.py
import httpx
import json
from django.conf import settings
from llm_integration.services import qualify_table_names
import psycopg2

class SupersetService:
    def __init__(self):
        self.base_url = settings.SUPERSET_BASE_URL
        self.username = settings.SUPERSET_USERNAME
        self.password = settings.SUPERSET_PASSWORD
        self.database_id = settings.SUPERSET_DATABASE_ID
        self.client = httpx.AsyncClient()
        self.access_token = None
    
    async def authenticate(self):
        auth_url = f"{self.base_url}/api/v1/security/login"
        payload = {
            "username": self.username,
            "password": self.password,
            "provider": "db",
            "refresh": True
        }
        
        response = await self.client.post(auth_url, json=payload)
        response.raise_for_status()
        self.access_token = response.json().get("access_token")
        
        # Get CSRF token
        csrf_url = f"{self.base_url}/api/v1/security/csrf_token/"
        headers = {"Authorization": f"Bearer {self.access_token}"}
        csrf_response = await self.client.get(csrf_url, headers=headers)
        csrf_response.raise_for_status()
        self.csrf_token = csrf_response.json().get("result")
    
    async def create_dataset(self, sql, table_name, database_id):
        """Create a virtual dataset in Superset."""
        if not self.access_token:
            await self.authenticate()
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        if hasattr(self, 'csrf_token') and self.csrf_token:
            headers["X-CSRFToken"] = self.csrf_token
        dataset_url = f"{self.base_url}/api/v1/dataset/"
        
        # Qualify table names in SQL
        qualified_sql = qualify_table_names(sql, schema="public")
        
        # Minimal payload with only required fields
        payload = {
            "database": database_id,
            "sql": qualified_sql,
            "table_name": table_name,
            "schema": "public"
        }
        
        try:
            response = await self.client.post(dataset_url, headers=headers, json=payload)
            response.raise_for_status()
            dataset_data = response.json()
            print(f"✅ Dataset created successfully: {table_name}")
            return dataset_data["id"]
        except httpx.HTTPStatusError as e:
            print(f"❌ Superset API Error creating dataset: {e}")
            print(f"   Response body: {e.response.text}")
            try:
                print(f"   Full error response: {e.response.content}")
            except Exception as ex:
                print(f"   Could not print full error response: {ex}")
            raise e
        except Exception as e:
            print(f"❌ An unexpected error occurred during dataset creation: {e}")
            raise e

    async def create_physical_view_and_dataset(self, sql, view_name, database_id):
        """Create a physical view in Postgres and register it as a dataset in Superset."""
        # 1. Create the view in Postgres
        db_settings = settings.DATABASES['default']
        conn = psycopg2.connect(
            dbname=db_settings['NAME'],
            user=db_settings['USER'],
            password=db_settings['PASSWORD'],
            host=db_settings['HOST'],
            port=db_settings.get('PORT', 5432)
        )
        qualified_sql = qualify_table_names(sql, schema="public")
        with conn.cursor() as cur:
            cur.execute(f"DROP VIEW IF EXISTS public.{view_name} CASCADE;")
            cur.execute(f"CREATE OR REPLACE VIEW public.{view_name} AS {qualified_sql}")
            conn.commit()
        conn.close()
        # 2. Register the view as a dataset in Superset
        if not self.access_token:
            await self.authenticate()
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        if hasattr(self, 'csrf_token') and self.csrf_token:
            headers["X-CSRFToken"] = self.csrf_token
        dataset_url = f"{self.base_url}/api/v1/dataset/"
        payload = {
            "database": database_id,
            "table_name": view_name,
            "schema": "public"
        }
        try:
            response = await self.client.post(dataset_url, headers=headers, json=payload)
            response.raise_for_status()
            dataset_data = response.json()
            print(f"✅ Physical view and dataset created: {view_name}")
            return dataset_data["id"]
        except Exception as e:
            print(f"❌ Error creating dataset for view {view_name}: {e}")
            raise e

    async def create_chart(self, dataset_id, chart_type, title, chart_spec=None):
        if not self.access_token:
            await self.authenticate()
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        if hasattr(self, 'csrf_token') and self.csrf_token:
            headers["X-CSRFToken"] = self.csrf_token
        chart_url = f"{self.base_url}/api/v1/chart/"
        # Use chart_spec fields if provided
        metrics = chart_spec.get("metrics") if chart_spec else []
        groupby = chart_spec.get("groupby") if chart_spec else []
        columns = chart_spec.get("columns") if chart_spec else []
        all_columns = chart_spec.get("all_columns") if chart_spec else []
        # Create appropriate chart parameters based on chart type
        if chart_type == "table":
            params = {
                "all_columns": all_columns or columns or [],
                "order_by_cols": [],
                "row_limit": 1000
            }
        elif chart_type in ("bar", "line", "pie"):
            params = {
                "metrics": metrics or [],
                "groupby": groupby or [],
                "adhoc_filters": [],
                "row_limit": 1000
            }
        else:
            params = {}
        payload = {
            "datasource_id": dataset_id,
            "datasource_type": "table",
            "viz_type": chart_type,
            "slice_name": title,
            "params": json.dumps(params),
        }
        try:
            response = await self.client.post(chart_url, headers=headers, json=payload)
            response.raise_for_status()
            chart_id = response.json()["id"]
            print(f"✅ Chart created successfully: {title} (ID: {chart_id})")
            return chart_id
        except Exception as e:
            print(f"❌ Chart creation failed for {title} as {chart_type}: {e}")
            # Fallback to table chart if other types fail, but only return the fallback
            if chart_type != "table":
                try:
                    return await self.create_chart(dataset_id, "table", title, chart_spec)
                except Exception as fallback_e:
                    print(f"❌ Fallback table chart creation also failed for {title}: {fallback_e}")
                    return None
            return None

    async def create_dashboard(self, title, chart_specs):
        """Create a dashboard with the given title and chart specifications."""
        if not self.access_token:
            await self.authenticate()
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        if hasattr(self, 'csrf_token') and self.csrf_token:
            headers["X-CSRFToken"] = self.csrf_token
        
        # Only use the first chart_spec to avoid multiple charts per dashboard
        if chart_specs:
            chart_specs = [chart_specs[0]]
        else:
            chart_specs = []
        
        chart_ids = []
        for i, chart_spec in enumerate(chart_specs):
            import time
            import uuid
            timestamp = int(time.time())
            view_name = f"ai_dashboard_view_{timestamp}_{uuid.uuid4().hex[:6]}"
            sql = chart_spec["sql"]
            print(f"[DEBUG] Chart {i} SQL: {sql}")
            # Skip if more than one SELECT in the SQL
            if str(sql).lower().count('select') > 1:
                print(f"[WARNING] Skipping chart {i} due to multiple SELECT statements in SQL.")
                continue

            try:
                print(f"[DEBUG] Creating physical view and dataset with SQL: {sql}")
                dataset_id = await self.create_physical_view_and_dataset(sql, view_name, self.database_id)
                chart_id = await self.create_chart(dataset_id, chart_spec["type"], chart_spec["title"], chart_spec)
                if chart_id:
                    chart_ids.append(chart_id)
            except Exception as e:
                print(f"❌ Failed to create chart or dataset for spec {i}: {e}")
                continue

        if not chart_ids:
            raise Exception("No charts could be created for the dashboard.")

        # Create an empty dashboard first
        dashboard_url = f"{self.base_url}/api/v1/dashboard/"
        import time
        timestamp = int(time.time())
        slug = f"ai_dashboard_{timestamp}"
        
        create_payload = {
            "dashboard_title": title,
            "slug": slug,
            "owners": [1],  # Default admin user ID
            "position_json": "{}"  # Start with empty layout
        }
        
        try:
            response = await self.client.post(dashboard_url, headers=headers, json=create_payload)
            response.raise_for_status()
            dashboard_data = response.json()
            dashboard_id = dashboard_data["id"]
            print(f"✅ Empty dashboard created: {title} (ID: {dashboard_id})")
        except Exception as e:
            print(f"❌ Failed to create empty dashboard: {e}")
            raise e

        # Update the dashboard with the chart layout
        position_json = self._generate_superset_layout(chart_ids)
        update_payload = {
            "position_json": json.dumps(position_json)
        }
        
        update_url = f"{self.base_url}/api/v1/dashboard/{dashboard_id}"
        
        try:
            response = await self.client.put(update_url, headers=headers, json=update_payload)
            response.raise_for_status()
            result = response.json().get("result", {})
            print(f"✅ Dashboard updated with charts: {title}")
            # Return the full dashboard data, including the URL
            dashboard_data['url'] = f"{self.base_url}/superset/dashboard/{dashboard_id}/"
            return dashboard_data
        except Exception as e:
            print(f"❌ Failed to update dashboard with charts: {e}")
            raise e

    def _generate_superset_layout(self, chart_ids):
        # Generate a valid Superset dashboard layout with ROOT, GRID, and CHART
        import uuid
        root_id = str(uuid.uuid4())
        grid_id = str(uuid.uuid4())
        layout = {
            root_id: {
                "type": "ROOT",
                "id": root_id,
                "children": [grid_id],
                "meta": {},
            },
            grid_id: {
                "type": "GRID",
                "id": grid_id,
                "children": [],
                "parents": [root_id],
                "meta": {},
            },
        }
        for i, chart_id in enumerate(chart_ids):
            chart_uuid = str(uuid.uuid4())
            layout[chart_uuid] = {
                "type": "CHART",
                "id": chart_uuid,
                "children": [],
                "parents": [grid_id],
                "meta": {"chartId": chart_id},
                "position": {"row": i, "col": 0},
            }
            layout[grid_id]["children"].append(chart_uuid)
        return layout